import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
    templateUrl: 'terms-condition.html'
})
export class TermsCondition {
   

    constructor(public nav: NavController) {

    }

}